#include <string>
#include <iostream>

void
displayResult(const int numPattern,
              const int nmbrResult);

bool
testRotation(const int ndx,
             const int ndy,
             const int numRotations,
             const int sizePattern,
             const bool reflection);

char
initialPattern[10][10];

char
finalPattern[10][10];

int
main() {
/*L01*/     std::string
            target;

/*L02*/     int
            numPatterns = 1;

/*L03*/     while (std::getline(std::cin, target)) {
/*L04*/       int
              sizePattern;

/*L05*/       try {
                sizePattern = std::stoi(target);
              }//try
              catch (...) {
                return 0;
              }//catch

/*L06*/       for (int ndy = 0; ndy < sizePattern; ndy++) {
                std::getline(std::cin, target, ' ');

                for (int ndx = 0; ndx < sizePattern; ndx++) {
                  initialPattern[ndx][ndy] = target[ndx];
                }//for

                std::getline(std::cin, target);
                for (int ndx = 0; ndx < sizePattern; ndx++) {
                  finalPattern[ndx][ndy] = target[ndx];
                }//for
              }//for

              //Test Preserved
/*L07*/       for (int ndy = 0; ndy < sizePattern; ndy++) {
                for (int ndx = 0; ndx < sizePattern; ndx++) {
                  if (initialPattern[ndx][ndy] != finalPattern[ndx][ndy]) {
                    goto testRotationsLbl;
                  }//if
                }//for
              }//for

/*L08*/       displayResult(numPatterns, 0);
/*L09*/       goto nextInputLbl;

              //Test Rotations
              testRotationsLbl: ;
/*L10*/       for (int ndz = 1; ndz < 4; ndz++) {
/*L11*/         for (int ndy = 0; ndy < sizePattern; ndy++) {
/*L12*/           for (int ndx = 0; ndx < sizePattern; ndx++) {
/*L13*/             if (!testRotation(ndx, ndy, ndz, sizePattern, false)) {
/*L14*/               goto testNextRotationLbl;
                    }//if
                  }//for
                }//for

/*L15*/         displayResult(numPatterns, ndz);
/*L16*/         goto nextInputLbl;
/*L17*/         testNextRotationLbl: ;
              }//for

              //Test Reflection
/*L18*/       testReflectionLbl: ;
              for (int ndy = 0; ndy < sizePattern; ndy++) {
                for (int ndx = 0; ndx < sizePattern; ndx++) {
                  if (initialPattern[ndx][ndy] !=
                      finalPattern[ndx][sizePattern - ndy - 1]) {
                    goto testCompositionsLbl;
                  }//if
                }//for
              }//for

/*L19*/       displayResult(numPatterns, 4);
/*L20*/       goto nextInputLbl;

              //Test Compositions
              testCompositionsLbl: ;
/*L21*/       for (int ndz = 1; ndz < 4; ndz++) {
/*L22*/         for (int ndy = 0; ndy < sizePattern; ndy++) {
/*L23*/           for (int ndx = 0; ndx < sizePattern; ndx++) {
/*L24*/             if (!testRotation(ndx, ndy, ndz, sizePattern, true)) {
/*L25*/               goto testNextCompositionLbl;
                    }//if
                  }//for
                }//for

/*L26*/         displayResult(numPatterns, ndz + 4);
/*L27*/         goto nextInputLbl;
/*L28*/         testNextCompositionLbl: ;
              }//for

/*L29*/       displayResult(numPatterns, 8);
/*L30*/       nextInputLbl: numPatterns++;
            }//while

/*L31*/     return 0;
}//main

void
displayResult(const int numPattern,
              const int nmbrResult) {
            std::string
            output = "Pattern ";
            output += std::to_string(numPattern);
            output += " was ";

            switch(nmbrResult) {
              case 0:
                output += "preserved.";
                break;
              case 1:
                output += "rotated 90 degrees.";
                break;
              case 2:
                output += "rotated 180 degrees.";
                break;
              case 3:
                output += "rotated 270 degrees.";
                break;
              case 4:
                output += "reflected vertically.";
                break;
              case 5:
                output += "reflected vertically and rotated 90 degrees.";
                break;
              case 6:
                output += "reflected vertically and rotated 180 degrees.";
                break;
              case 7:
                output += "reflected vertically and rotated 270 degrees.";
                break;
              case 8:
                output += "improperly transformed.";
                break;
            }//switch

/*L01*/     std:: cout << output << std::endl;

/*L02*/     return;
}//displayResult

bool
testRotation(const int ndx,
             const int ndy,
             const int numRotations,
             const int sizePattern,
             const bool reflection) {
/*L01*/     int
            finalNdx(ndx),
            finalNdy,
            temp;

/*L02*/     if (reflection) {
/*L03*/       finalNdy = sizePattern - ndy -1;
            }//if
/*L04*/     else {
/*L05*/       finalNdy = ndy;
            }//else

/*L06*/     for (int ndz = 0; ndz < numRotations; ndz++) {
/*L07*/       temp = finalNdx;
/*L08*/       finalNdx = sizePattern - finalNdy - 1;
/*L09*/       finalNdy = temp;
            }//for

/*L10*/     if (initialPattern[ndx][ndy] == finalPattern[finalNdx][finalNdy]) {
/*L11*/       return true;
            }//if
/*L12*/     else {
/*L13*/       return false;
            }//else
}//testRotation
